package org.junit;

public @interface Test {

}
