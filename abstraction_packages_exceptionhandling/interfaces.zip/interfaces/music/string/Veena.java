package abstraction_packages_exceptionhandling.interfaces.music.string;

import abstraction_packages_exceptionhandling.interfaces.music.Playable;

public class Veena implements Playable {

	@Override
	public void play() {
		// TODO Auto-generated method stub
		System.out.println("Veena sounds beautiful.");
	}

}

