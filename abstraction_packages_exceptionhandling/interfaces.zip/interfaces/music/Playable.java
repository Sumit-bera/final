package abstraction_packages_exceptionhandling.interfaces.music;

public interface Playable {
	void play();
}
