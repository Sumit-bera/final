package abstraction_packages_exceptionhandling.packages.com.automobile1;

public abstract class Vehicle {
	
	public abstract String getModelName();
	public abstract String getRegistrationNumber(); 
	public abstract String getOwnerName(); 
}
